# Rede Cloud does not require custom ProGuard rules for the WebView shell.
